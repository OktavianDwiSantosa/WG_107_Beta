package main;

import required.enums.Direction;
import required.Thing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Room extends Thing {
    private final int roomID;
    private boolean isVisited;
    private HashMap<Direction, Room> nextRoom = new HashMap<>();
    private ArrayList<String> story = new ArrayList<>();

    public Room(String vName, int vRoomID) {
        super(vName, "");
        roomID = vRoomID;
    }

    public void moveToNextRoom(Direction userChoice) {
        if (getNextRoom().get(userChoice) != null) {
            GameInfo.activeRoom = getNextRoom().get(userChoice);
            System.out.println("\nYou are moving into the " + userChoice.toString() + "!");
        } else System.out.println("\nYou can't go in that direction!");
    }

    private void roomVisited() {
        if (!isVisited) {
            Scanner sc = new Scanner(System.in);
            for (String vStory : story) {
                System.out.println(vStory);
                String next = sc.nextLine();
            }
            isVisited = true;
        }
    }

    // Getter
    public int getRoomID() {
        return roomID;
    }

    public HashMap<Direction, Room> getNextRoom() {
        return nextRoom;
    }

    public void addNextRoom(Direction direction, Room room) {
        nextRoom.put(direction, room);
    }

    public void addStory(String vStory) {
        story.add(vStory);
    }

    public void addStories() {
        // Salah deng, harusnya story simpan di file.txt aja,
        // habis itu dibaca dari file.txt mirip-mirip kaya pakai Scanner(System.in)
        // ada cara untuk baca file di Java itu pakai FileInputStream & ObjectInputStream;
        Scanner sc = new Scanner(System.in);
        while (!sc.nextLine().equals(";")) {
            addStory(sc.nextLine());
        }
    }

    public boolean isVisited() {
        return isVisited;
    }
}
