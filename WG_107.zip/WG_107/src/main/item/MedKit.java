package main.item;

import main.Hero;
import required.Consumable;
import required.Item;
import required.multipliers.Health;
import required.enums.Operator;
import required.Thing;
import required.enums.RarityType;

public class MedKit extends Item implements Consumable {
    private Health healthMultiplier;

    public MedKit(String vName, String vDescription, Thing vOwner,
                  int vPrice, RarityType vRarity, Health vHealthMultiplier) {
        super(vName, vDescription, vOwner, vPrice, vRarity);
        healthMultiplier = vHealthMultiplier;
    }

    public MedKit(String vName, String vDescription, int vPrice,
                  RarityType vRarity, Health vHealthMultiplier) {
        super(vName, vDescription, null, vPrice, vRarity);
        healthMultiplier = vHealthMultiplier;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        MedKit newClone = (MedKit) super.clone();
        newClone.healthMultiplier = (Health) this.healthMultiplier.clone();
        return newClone;
    }

    @Override
    public void describe() {
        super.describe();
        healthMultiplier.printProbability();
    }

    @Override
    public void used(Thing healTarget) {
        if (healTarget.getTrueClassName().equals("Hero")) {
            Hero tempHero = (Hero) healTarget;

            // tambah max health hero
            healthMultiplier.applyEqValue(Operator.ADDITION, tempHero);

            // Java akan otomatis menghapus objek ke dalam garbage collection,
            // ketika kita tidak me-referensi objek ini lagi
            getOwner().removeThing(this);
        }
    }

}
