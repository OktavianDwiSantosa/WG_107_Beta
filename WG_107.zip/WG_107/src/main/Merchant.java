package main;

import required.Item;
import required.Thing;
import required.enums.ModifiedType;
import required.prototype.MaterialPrototype;
import required.prototype.MedKitPrototype;
import view.BasicView;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public final class Merchant extends Thing {
    private static Merchant theMerchant;

    private Merchant() {
        super("Stranger Merchant", "He was just a strange stranger merchant");
    }

    // Singleton
    public static Merchant getMerchant() {
        if (theMerchant == null) {
            theMerchant = new Merchant();
            MaterialPrototype objMaterials = new MaterialPrototype();
            MedKitPrototype objMedKits = new MedKitPrototype();

            try {
                objMedKits.gets("Binder", 50, theMerchant);
                objMedKits.gets("Mender", 30, theMerchant);
                objMedKits.gets("Xander", 10, theMerchant);
                objMaterials.gets("Iron Ore", 4, theMerchant);
                objMaterials.gets("Copper", 4, theMerchant);
                objMaterials.gets("Gold", 1, theMerchant);
                objMaterials.gets("Onyx", 1, theMerchant);
            } catch (CloneNotSupportedException vE) {
                vE.printStackTrace();
            }
        }
        return theMerchant;
    }

    public void merchantMenu() {
        Scanner sc = new Scanner(System.in);
        int selectMenu = -1;

        while (selectMenu != 0) {
            BasicView.headerMenu("Welcome Stranger!", 40);
            System.out.println("""
                    [1] Buy
                    [2] Sell
                    [3] Craft
                    [4] Upgrade
                    [0] Cancel""");
            BasicView.footerMenu("Choose menu : ", 40);
            selectMenu = sc.nextInt();

            switch (selectMenu) {
                case 0 -> System.out.println("See you later stranger!");
                case 1 -> transactionMenu(ModifiedType.BUY);
                case 2 -> transactionMenu(ModifiedType.SELL);
                case 3 -> transactionMenu(ModifiedType.CRAFT);
                case 4 -> transactionMenu(ModifiedType.UPGRADE);
                default -> System.out.println("Your choice doesn't available!");
            }
        }
    }

    private void itemsLooping(ArrayList<Thing> tempItem) {
        for (int i = 0; i < tempItem.size(); i++) {
            Thing objItem = tempItem.get(i);
            System.out.print("[" + (i + 1) + "] ");
            objItem.describe();
        }
        System.out.println("\n" + "=".repeat(30));
    }

    private ArrayList<Thing> itemTypeToModified(ModifiedType vModifiedType, Thing vOwner) {
        ArrayList<Thing> tempItem = null;
        Scanner sc = new Scanner(System.in);
        int selectItem = -1;

        while (selectItem != 0) {
            BasicView.headerMenu((vModifiedType.toString() + " Item"), 40);
            System.out.println("[1] Armor");
            System.out.println("[2] Weapon");
            if (vModifiedType == ModifiedType.BUY || vModifiedType == ModifiedType.SELL) {
                System.out.println("[3] Material");
                System.out.println("[4] MedKit");
            }
            System.out.println("[0] Cancel");
            BasicView.footerMenu("Select item type : ", 40);

            try {
                selectItem = sc.nextInt();

                switch (selectItem) {
                    case 0 -> System.out.println("You canceled the transaction!");
                    case 1 -> tempItem = vOwner.getOneClass("Armor");
                    case 2 -> tempItem = vOwner.getOneClass("Weapon");
                    case 3, 4 -> tempItem = checkTransaction(vModifiedType, selectItem);
                    default -> System.out.println("Your choice doesn't available!");
                }
            } catch (InputMismatchException e) { // jika input bukan integer
                System.out.println("Your input doesn't valid!");
                sc = new Scanner(System.in);
            }
        }

        return tempItem;
    }

    private ArrayList<Thing> checkTransaction(ModifiedType vModifiedType, int selectItem) {
        ArrayList<Thing> tempItem = null;
        if (vModifiedType == ModifiedType.BUY || vModifiedType == ModifiedType.SELL) {
            if (selectItem == 3)
                tempItem = this.getOneClass("Material");
            else if (selectItem == 4)
                tempItem = this.getOneClass("MedKit");
            else System.out.println("\nYour choice doesn't available!\n");
        } else System.out.println("\nYour choice doesn't available!\n");

        return tempItem;
    }

    private void transactionMenu(ModifiedType vModifiedType) {
        ArrayList<Thing> tempItem;
        if (vModifiedType == ModifiedType.BUY || vModifiedType == ModifiedType.CRAFT) {
            tempItem = itemTypeToModified(vModifiedType, this);
        } else {
            tempItem = itemTypeToModified(vModifiedType, GameInfo.userInventory);
        }

        if (tempItem != null) {
            Scanner sc = new Scanner(System.in);

            BasicView.headerMenu((vModifiedType.toString() + " Item"), 40);
            itemsLooping(tempItem);
            BasicView.footerMenu("Select item to " + vModifiedType.toString(), 40);

            try {
                int selectItem = sc.nextInt();
                if (((Item) tempItem.get(selectItem - 1)).modified(vModifiedType)) {
                    System.out.println("Well Done stranger!\nItem has been successfully "
                            + vModifiedType + "!");
                } else {
                    System.out.println("Sorry stranger!\nItem cannot be "
                            + vModifiedType + "!");
                }
            } catch (InputMismatchException e) {
                System.out.println("\nYour input doesn't valid!");
            }
        } else {
            System.out.println("Sorry stranger!\nSeems you have no item to "
                    + vModifiedType + "!");
        }
    }

}
