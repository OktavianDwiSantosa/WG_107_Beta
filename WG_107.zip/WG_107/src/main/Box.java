package main;

import required.Item;
import required.Thing;

public class Box extends Thing {
    private final int axel;
    private boolean isOpened;

    public Box(String vName, String vDescription, int vAxel) {
        super(vName, vDescription);
        axel = vAxel;
    }

    @Override
    public void describe() {
        super.describe();
        System.out.println("Axel : " + getAxel());
        showAllClass();
    }

    public void opened() {
        if (!isOpened) {
            GameInfo.userInventory.addAxel(axel);
            System.out.printf("\nYou have been opened the %s!\n", getName());
            describe();

            for (Thing objItem : getArrThing()) {
                ((Item) objItem).moveTo(GameInfo.userInventory);
            }

            isOpened = true;
        } else {
            System.out.println("\n " + getName() + " is empty!");
            System.out.println(getName() + " has been opened before!\n");
        }
    }

    // Getter & Setter
    public int getAxel() {
        return axel;
    }

}
