package required.enums;

public enum ArmorType {
    HEAVY, ROBE

    /*
     * Heavy --> health (higher) & shield
     * Robe --> health & shield (higher)
     */
}
