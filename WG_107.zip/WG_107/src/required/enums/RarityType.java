package required.enums;

public enum RarityType {
    COMMON, RARE, EPIC, LEGENDARY
}
