package required;

public interface Ownerable {

    void switchOwner(Thing newOwner);

    void moveTo(Thing newOwner);
}
