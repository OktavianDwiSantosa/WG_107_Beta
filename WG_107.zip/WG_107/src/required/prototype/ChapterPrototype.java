package required.prototype;

import main.Chapter;
import main.Room;
import required.Thing;

public class ChapterPrototype extends BundledPrototype {
    public ChapterPrototype() throws CloneNotSupportedException {
        Chapter obj1 = new Chapter("Broken World", 1);
        Chapter obj2 = new Chapter("Pursuit by Time", 2);
        Chapter obj3 = new Chapter("Into the Forest", 3);
        Chapter obj4 = new Chapter("Mountains", 4);
        Chapter obj5 = new Chapter("The White Gate", 5);

        MaterialPrototype objMaterials = new MaterialPrototype();
        MedKitPrototype objMedKits = new MedKitPrototype();
        ArmorPrototype objArmors = new ArmorPrototype();
        WeaponPrototype objWeapons = new WeaponPrototype();
        BoxPrototype objBoxes = new BoxPrototype();
        SkillPrototype objSkills = new SkillPrototype();
        HeroPrototype objHeroes = new HeroPrototype();
        EnemyPrototype objEnemies = new EnemyPrototype();
        RoomPrototype objRooms = new RoomPrototype();

        Thing room1 = objRooms.get("Bar break room");
        ((Room) room1).addStories();

        Thing cityCenterAttacked = objRooms.get("Pelusium city center");
        cityCenterAttacked.getArrThing().clear();
        cityCenterAttacked.addSameThings(objEnemies.get("Droid X1"), 4);
        obj2.addThing(cityCenterAttacked);

        Thing mainBarBurn = objRooms.get("Main bar");
        mainBarBurn.getArrThing().clear();
        Thing objBox1 = objBoxes.get("Common Supply");
        objMaterials.gets("Copper", 5, objBox1);
        objMaterials.gets("Iron Ore", 4, objBox1);
        mainBarBurn.addSameThings(objEnemies.get("Droid X2"), 3);
        obj3.addThing(mainBarBurn);

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
    }
}
