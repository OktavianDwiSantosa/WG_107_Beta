package required.prototype;

import main.item.Armor;
import required.Item;
import required.Thing;
import required.builders.equipment.EquipmentBuilders;
import required.enums.ArmorType;
import required.enums.RarityType;

public class ArmorPrototype extends BundledPrototype {
    public ArmorPrototype() {
        Armor obj1 = EquipmentBuilders.newArmor()
                .name("Alva")
                .description("An armor form the Abyss")
                .price(200)
                .rarity(RarityType.COMMON)
                .level(1)
                .armorType(ArmorType.HEAVY)
                .healthMultiplier(0.284)
                .shieldMultiplier(0.163)
                .requiredMaterials("Iron Ore", 4)
                .requiredMaterials("Onyx", 3)
                .build();

        Armor obj2 = EquipmentBuilders.newArmor()
                .name("Drakeblood")
                .description("A Red exotic armor")
                .price(400)
                .rarity(RarityType.RARE)
                .level(1)
                .armorType(ArmorType.HEAVY)
                .healthMultiplier(0.312)
                .shieldMultiplier(0.189)
                .build();

        Armor obj3 = EquipmentBuilders.newArmor()
                .name("Black Hand")
                .description("A jet black armor")
                .price(400)
                .rarity(RarityType.RARE)
                .level(1)
                .armorType(ArmorType.HEAVY)
                .healthMultiplier(0.323)
                .shieldMultiplier(0.157)
                .build();

        Armor obj4 = EquipmentBuilders.newArmor()
                .name("Favorius Dawn")
                .description("A dazzling yellow armor")
                .price(800)
                .rarity(RarityType.EPIC)
                .level(1)
                .armorType(ArmorType.HEAVY)
                .healthMultiplier(0.423)
                .shieldMultiplier(0.212)
                .build();

        Armor obj5 = EquipmentBuilders.newArmor()
                .name("Sentinel")
                .description("A big heavy white armor")
                .price(1600)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .armorType(ArmorType.HEAVY)
                .healthMultiplier(0.523)
                .shieldMultiplier(0.278)
                .build();

        Armor obj6 = EquipmentBuilders.newArmor()
                .name("Nighthawk Leather")
                .description("A black robe that is darker than the night")
                .price(200)
                .rarity(RarityType.COMMON)
                .level(1)
                .armorType(ArmorType.ROBE)
                .healthMultiplier(0.133)
                .shieldMultiplier(0.271)
                .build();

        Armor obj7 = EquipmentBuilders.newArmor()
                .name("Deserter")
                .description("A light fawn cloak")
                .price(400)
                .rarity(RarityType.RARE)
                .level(1)
                .armorType(ArmorType.ROBE)
                .healthMultiplier(0.174)
                .shieldMultiplier(0.317)
                .build();

        Armor obj8 = EquipmentBuilders.newArmor()
                .name("Raiment of Delusions")
                .description("A deceiving robe")
                .price(400)
                .rarity(RarityType.RARE)
                .level(1)
                .armorType(ArmorType.ROBE)
                .healthMultiplier(0.153)
                .shieldMultiplier(0.341)
                .build();

        Armor obj9 = EquipmentBuilders.newArmor()
                .name("Spectral Shroud of Sunlight")
                .description("A charming yellow robe")
                .price(800)
                .rarity(RarityType.EPIC)
                .level(1)
                .armorType(ArmorType.ROBE)
                .healthMultiplier(0.195)
                .shieldMultiplier(0.444)
                .build();

        Armor obj10 = EquipmentBuilders.newArmor()
                .name("Cape of Dawn")
                .description("A luxurious golden robe")
                .price(1600)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .armorType(ArmorType.ROBE)
                .healthMultiplier(0.267)
                .shieldMultiplier(0.579)
                .build();

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
    }

    public void gets(String vName, Thing vOwner) throws CloneNotSupportedException {
        ((Item) get(vName)).moveTo(vOwner);
    }
}
