package required.prototype;

import main.Hero;
import required.enums.ArmorType;
import required.enums.WeaponType;

public class HeroPrototype extends BundledPrototype {
    public HeroPrototype() throws CloneNotSupportedException {
        Hero obj1 = new Hero("Elon", "An older brother who has a mission to find his sister",
                1, 1, 50, 15, 20,
                WeaponType.SWORD, ArmorType.HEAVY);

        Hero obj2 = new Hero("Farlan", "A soldier who is loyal to his comrades",
                1, 1, 40, 35, 10,
                WeaponType.PROJECTILE, ArmorType.ROBE);

        Hero obj3 = new Hero("Jojo", "A strong and sturdy boxer",
                1, 1, 60, 10, 20,
                WeaponType.GAUNTLET, ArmorType.HEAVY);

        Hero obj4 = new Hero("Raikou", "A swordsman who cares about his comrades",
                1, 1, 45, 25, 15,
                WeaponType.SABER, ArmorType.ROBE);

        Hero obj5 = new Hero("Tony", "A reliable tech maniac",
                1, 1, 35, 25, 15,
                WeaponType.CYBERWARE, ArmorType.ROBE);

        SkillPrototype objSkills = new SkillPrototype();

        objSkills.gets("Wind Blade", obj1);
        objSkills.gets("Coldwind Slash", obj1);
        objSkills.gets("Implosion", obj1);
        objSkills.gets("Blade of Shapire", obj1);
        objSkills.gets("Endless Battle", obj1);
        objSkills.gets("Revitalize", obj1);
        objSkills.gets("Oracle", obj1);

        objSkills.gets("Tiger Pounce", obj2);
        objSkills.gets("Soulbreak", obj2);
        objSkills.gets("Shadow Eruption", obj2);
        objSkills.gets("Rose Gold", obj2);
        objSkills.gets("Fierce Strike", obj2);
        objSkills.gets("Aegis", obj2);
        objSkills.gets("Thunder Belt", obj2);
        objSkills.gets("Black Ice Shield", obj2);

        objSkills.gets("Shadowhand", obj3);
        objSkills.gets("Dark Knight", obj3);
        objSkills.gets("Dark Pulse", obj3);
        objSkills.gets("Windtalker", obj3);
        objSkills.gets("Predatory Hunt", obj3);
        objSkills.gets("Guardian Helmet", obj3);
        objSkills.gets("Dreadnought Armor", obj3);

        objSkills.gets("Slaughter Ring", obj4);
        objSkills.gets("Illusion", obj4);
        objSkills.gets("Soul Siphon", obj4);
        objSkills.gets("Headbutt", obj4);
        objSkills.gets("Ultimate Thunderstorms", obj4);
        objSkills.gets("Regen", obj4);
        objSkills.gets("Blade Armor", obj4);
        objSkills.gets("Athena Shield", obj4);

        objSkills.gets("Frozen Blade", obj5);
        objSkills.gets("Demon Blade", obj5);
        objSkills.gets("Wrath of Chaos", obj5);
        objSkills.gets("Blade Phantom", obj5);
        objSkills.gets("Fire Chaos", obj5);
        objSkills.gets("Immortality", obj5);
        objSkills.gets("Ares Belt", obj5);
        objSkills.gets("Vitality Crystal", obj5);

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
    }
}
