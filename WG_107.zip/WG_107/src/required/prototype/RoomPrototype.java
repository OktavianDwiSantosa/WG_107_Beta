package required.prototype;

import main.GameInfo;
import main.Room;
import required.Thing;

public class RoomPrototype extends BundledPrototype {
    public RoomPrototype() throws CloneNotSupportedException {
        // Chapter 1
        Room obj1 = new Room("Bar break room", 1);
        Room obj2 = new Room("Training room 1", 2);
        Room obj3 = new Room("Training room 2", 3);
        Room obj4 = new Room("Training room 3", 4);
        Room obj5 = new Room("Main bar", 5);
        Room obj6 = new Room("Pelusium city center", 6);
        Room obj7 = new Room("Bar equipment room", 7);
        Room obj8 = new Room("City center exit", 8);
        Room obj9 = new Room("Main street of the city", 9);
        Room obj10 = new Room("Under the bridge", 10);
        Room obj11 = new Room("Shop at the end of the main road", 11);
        Room obj12 = new Room("City sewer", 12);
        Room obj13 = new Room("The road to the bar", 13);
        Room obj14 = new Room("The road near the bar", 14);
        Room obj15 = new Room("Shop near the bar", 15);
        Room obj16 = new Room("Bar yard", 16);
        Room obj17 = new Room("Forest edge", 17);
        Room obj18 = new Room("Shop on the edge of the forest", 18);
        Room obj19 = new Room("The first forest area", 19);
        Room obj20 = new Room("The second forest area", 20);
        Room obj21 = new Room("The third forest area", 21);
        Room obj22 = new Room("Shop in the forest", 22);
        Room obj23 = new Room("The fourth forest area", 23);
        Room obj24 = new Room("The fifth forest area", 24);
        Room obj25 = new Room("Old building in the forest", 25);
        Room obj26 = new Room("Alpine foothills", 26);
        Room obj27 = new Room("The road to the climbing post", 27);
        Room obj28 = new Room("Abandoned climbing post", 28);
        Room obj29 = new Room("Active fault road", 29);
        Room obj30 = new Room("Village near the cliff", 30);
        Room obj31 = new Room("Shop at the village near the cliff", 31);
        Room obj32 = new Room("Footpath on the edge of city", 32);
        Room obj33 = new Room("The old hut at the end of footpath", 33);
        Room obj34 = new Room("Outskirts of Heliopolis", 34);
        Room obj35 = new Room("Michel's Hideout", 35);
        Room obj36 = new Room("Cube Inc Basement", 36);
        Room obj37 = new Room("Cube Inc Fifty Floor", 37);
        Room obj38 = new Room("Cube Inc Secret Hallway 1", 38);
        Room obj39 = new Room("Cube Inc Secret Hallway 2", 39);
        Room obj40 = new Room("Cube Inc Secret Hallway 3", 40);
        Room obj41 = new Room("End of secret hallway", 41);
        Room obj42 = new Room("Cube Inc Research Room", 42);
        Room obj43 = new Room("Cube Inc Research Room End", 43);

        BoxPrototype objBoxes = new BoxPrototype();
        MaterialPrototype objMaterials = new MaterialPrototype();
        MedKitPrototype objMedKits = new MedKitPrototype();
        WeaponPrototype objWeapons = new WeaponPrototype();
        ArmorPrototype objArmors = new ArmorPrototype();
        EnemyPrototype objEnemies = new EnemyPrototype();

        obj1.addSameThings(objBoxes.get("Wooden Barrel"), 2);

        obj2.addSameThings(objBoxes.get("Wooden Box"), 3);
        obj2.addSameThings(objEnemies.get("Training Droid Y1"), 2);

        obj3.addThing(objBoxes.get("Wooden Box"));
        obj3.addSameThings(objBoxes.get("Wooden Barrel"), 2);
        obj3.addSameThings(objEnemies.get("Training Droid Y2"), 2);

        Thing objBox1 = objBoxes.get("Common Supply");
        objMaterials.gets("Iron Ore", 2, objBox1);
        obj4.addThing(objBox1);
        obj4.addSameThings(objEnemies.get("Training Droid Y3"), 2);

        obj6.addSameThings(objBoxes.get("Wooden Box"), 5);
        obj6.addSameThings(objBoxes.get("Wooden Barrel"), 7);
        obj6.addThing(GameInfo.theMerchant);

        Thing objBox3 = objBoxes.get("Exquisite Supply");
        objMaterials.gets("Copper", 2, objBox3);
        objWeapons.gets("Thalassa", objBox3);
        objArmors.gets("Nighthawk Leather", objBox3);
        obj7.addThing(objBox3);

        obj8.addSameThings(objEnemies.get("Droid X1"), 2);

        obj9.addSameThings(objEnemies.get("Droid X1"), 3);

        obj10.addSameThings(objEnemies.get("Droid X1"), 4);

        obj11.addThing(GameInfo.theMerchant);

        Thing objBox4 = objBoxes.get("Exquisite Supply");
        objMaterials.gets("Gold", 2, objBox4);
        obj12.addThing(objBox4);
        obj12.addSameThings(objBoxes.get("Wooden Box"), 5);

        obj13.addSameThings(objEnemies.get("Droid X2"), 2);

        obj14.addSameThings(objEnemies.get("Droid X2"), 3);

        obj15.addThing(GameInfo.theMerchant);

        obj16.addSameThings(objEnemies.get("Droid X2"), 2);
        obj16.addSameThings(objEnemies.get("Droid X3"), 2);

        obj17.addSameThings(objEnemies.get("Droid X1"), 2);
        obj17.addSameThings(objEnemies.get("Droid X2"), 2);

        Thing objBox5 = objBoxes.get("Exquisite Supply");
        objMaterials.gets("Onyx", 2, objBox5);
        objMedKits.gets("Mender", 3, objBox5);
        obj17.addThing(objBox5);
        obj17.addSameThings(objEnemies.get("Droid X2"), 3);

        obj18.addThing(GameInfo.theMerchant);

        obj19.addSameThings(objEnemies.get("Droid X2"), 3);

        obj20.addSameThings(objEnemies.get("Droid X2"), 1);
        obj20.addSameThings(objEnemies.get("Droid X1"), 2);

        obj21.addSameThings(objEnemies.get("Droid X2"), 1);
        obj21.addSameThings(objEnemies.get("Droid X1"), 3);

        obj22.addThing(GameInfo.theMerchant);

        obj23.addSameThings(objEnemies.get("Droid X2"), 2);

        obj24.addSameThings(objEnemies.get("Droid X3"), 4);

        obj25.addSameThings(objBoxes.get("Wooden Box"), 5);
        obj25.addSameThings(objBoxes.get("Wooden Barrel"), 4);

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
        cache.put(obj11.getName(), obj11);
        cache.put(obj12.getName(), obj12);
        cache.put(obj13.getName(), obj13);
        cache.put(obj14.getName(), obj14);
        cache.put(obj15.getName(), obj15);
        cache.put(obj16.getName(), obj16);
        cache.put(obj17.getName(), obj17);
        cache.put(obj18.getName(), obj18);
        cache.put(obj19.getName(), obj19);
        cache.put(obj20.getName(), obj20);
        cache.put(obj21.getName(), obj21);
        cache.put(obj22.getName(), obj22);
        cache.put(obj23.getName(), obj23);
        cache.put(obj24.getName(), obj24);
        cache.put(obj25.getName(), obj25);
        cache.put(obj26.getName(), obj26);
        cache.put(obj27.getName(), obj27);
        cache.put(obj28.getName(), obj28);
        cache.put(obj29.getName(), obj29);
        cache.put(obj30.getName(), obj30);
        cache.put(obj31.getName(), obj31);
        cache.put(obj32.getName(), obj32);
        cache.put(obj33.getName(), obj33);
        cache.put(obj34.getName(), obj34);
        cache.put(obj35.getName(), obj35);
        cache.put(obj36.getName(), obj36);
        cache.put(obj37.getName(), obj37);
        cache.put(obj38.getName(), obj38);
        cache.put(obj39.getName(), obj39);
        cache.put(obj40.getName(), obj40);
        cache.put(obj41.getName(), obj41);
        cache.put(obj42.getName(), obj42);
        cache.put(obj43.getName(), obj43);
    }
}
