package required.prototype;

import main.item.Material;
import required.Item;
import required.Thing;
import required.enums.RarityType;

public class MaterialPrototype extends BundledPrototype {
    public MaterialPrototype() {
        Material obj1 = new Material("Iron Ore", "An ordinary iron ore",
                50, RarityType.COMMON);
        Material obj2 = new Material("Copper", "A simple copper",
                50, RarityType.COMMON);
        Material obj3 = new Material("Gold", "A pure gold",
                100, RarityType.RARE);
        Material obj4 = new Material("Onyx", "A dark black little stone",
                100, RarityType.RARE);
        Material obj5 = new Material("Diamond", "A dazzle diamond",
                200, RarityType.EPIC);
        Material obj6 = new Material("Safir", "A valuable blue stone",
                200, RarityType.EPIC);
        Material obj7 = new Material("Zicron", "A valuable red stone",
                200, RarityType.EPIC);
        Material obj8 = new Material("Agate", "A valuable green stone",
                200, RarityType.EPIC);
        Material obj9 = new Material("Quartz", "A valuable yellow stone",
                200, RarityType.EPIC);
        Material obj10 = new Material("Garnet", "A glorious purple stone",
                500, RarityType.LEGENDARY);
        Material obj11 = new Material("Jasper", "A glorious silver stone",
                500, RarityType.LEGENDARY);
        Material obj12 = new Material("Platinum", "A glorious platinum",
                500, RarityType.LEGENDARY);
        Material obj13 = new Material("Animal Skin", "A very valuable animal skin",
                200, RarityType.EPIC);

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
        cache.put(obj11.getName(), obj11);
        cache.put(obj12.getName(), obj12);
        cache.put(obj13.getName(), obj13);
    }

    public void gets(String vName, int vAmount, Thing vOwner) throws CloneNotSupportedException {
        for (int i = 0; i < vAmount; i++) ((Item) get(vName)).moveTo(vOwner);
    }
}
