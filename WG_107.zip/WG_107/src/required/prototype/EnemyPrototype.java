package required.prototype;

import main.Enemy;

public class EnemyPrototype extends BundledPrototype {
    public EnemyPrototype() throws CloneNotSupportedException {
        Enemy obj1 = new Enemy("Droid X1", "The X1 version patrol droid made by Cube Inc",
                1, 10, 50, 10, 15, 10);

        Enemy obj2 = new Enemy("Droid X2", "The X2 version patrol droid made by Cube Inc",
                2, 20, 55, 15, 15, 20);

        Enemy obj3 = new Enemy("Droid X3", "The X3 version patrol droid made by Cube Inc",
                2, 20, 60, 20, 20, 25);

        Enemy obj4 = new Enemy("Droid X4", "The X4 version patrol droid made by Cube Inc",
                4, 40, 65, 25, 20, 40);

        Enemy obj5 = new Enemy("Droid X5", "The X5 version patrol droid made by Cube Inc",
                5, 50, 70, 25, 25, 50);

        Enemy obj6 = new Enemy("Droid X6", "The X6 version patrol droid made by Cube Inc",
                6, 60, 75, 35, 30, 60);

        Enemy obj7 = new Enemy("Droid X7", "The X7 version patrol droid made by Cube Inc",
                10, 100, 90, 50, 45, 100);

        Enemy obj8 = new Enemy("Droid X8", "The X8 version patrol droid made by Cube Inc",
                15, 145, 130, 70, 60, 150);

        Enemy obj9 = new Enemy("Bear", "A ferocious wild bear",
                15, 150, 150, 85, 65, 150);

        Enemy obj10 = new Enemy("Tiger", "A fierce wild tiger",
                15, 155, 150, 90, 55, 155);

        Enemy obj11 = new Enemy("Wolf", "A wild wolf on a rampage",
                15, 145, 150, 80, 60, 145);

        Enemy obj12 = new Enemy("Humanoid Z1", "The Z1 version guard droid made by Cube Inc",
                21, 185, 180, 130, 100, 220);

        Enemy obj13 = new Enemy("Humanoid Z2", "The Z2 version guard droid made by Cube Inc",
                22, 195, 170, 150, 105, 230);

        Enemy obj14 = new Enemy("Humanoid Z3", "The Z3 version guard droid made by Cube Inc",
                23, 235, 210, 165, 115, 245);

        Enemy obj15 = new Enemy("Humanoid Z4", "The Z4 version guard droid made by Cube Inc",
                25, 255, 235, 175, 125, 255);

        Enemy obj16 = new Enemy("General Axel", "The general of Cube Inc",
                30, 195, 170, 150, 105, 230);

        Enemy obj17 = new Enemy("Training Droid Y1", "Training droid made by Geheimnis",
                1, 4, 20, 3, 4, 3);

        Enemy obj18 = new Enemy("Training Droid Y2", "Training droid made by Geheimnis",
                1, 5, 22, 5, 7, 5);

        Enemy obj19 = new Enemy("Training Droid Y3", "Training droid made by Geheimnis",
                1, 6, 25, 8, 9, 8);

        MaterialPrototype objMaterials = new MaterialPrototype();
        SkillPrototype objSkills = new SkillPrototype();

        objMaterials.gets("Iron Ore", 2, obj1);
        objMaterials.gets("Copper", 1, obj1);
        objSkills.gets("Laser Shot", obj1);
        objSkills.gets("Bomb Throw", obj1);
        objSkills.gets("Rocket Launcher", obj1);

//        obj1.addSameThings(objMaterials.get("Iron Ore"), 2);
//        obj1.addThing(objMaterials.get("Copper"));
//        obj1.addThing(objSkills.get("Laser Shot"));
//        obj1.addThing(objSkills.get("Bomb Throw"));
//        obj1.addThing(objSkills.get("Rocket Launcher"));

        objMaterials.gets("Iron Ore", 1, obj2);
        objMaterials.gets("Copper", 2, obj2);
        objSkills.gets("Laser Shot", obj2);
        objSkills.gets("Bomb Throw", obj2);
        objSkills.gets("Rocket Launcher", obj2);

//        obj2.addSameThings(objMaterials.get("Copper"), 2);
//        obj2.addThing(objMaterials.get("Iron Ore"));
//        obj2.addThing(objSkills.get("Laser Shot"));
//        obj2.addThing(objSkills.get("Bomb Throw"));
//        obj2.addThing(objSkills.get("Rocket Launcher"));

        objMaterials.gets("Iron Ore", 2, obj3);
        objMaterials.gets("Copper", 2, obj3);
        objSkills.gets("Laser Shot", obj3);
        objSkills.gets("Bomb Throw", obj3);
        objSkills.gets("Rocket Launcher", obj3);

//        obj3.addSameThings(objMaterials.get("Iron Ore"), 2);
//        obj3.addSameThings(objMaterials.get("Copper"), 2);
//        obj3.addThing(objSkills.get("Laser Shot"));
//        obj3.addThing(objSkills.get("Bomb Throw"));
//        obj3.addThing(objSkills.get("Rocket Launcher"));

        objMaterials.gets("Iron Ore", 5, obj4);
        objMaterials.gets("Copper", 4, obj4);
        objSkills.gets("Laser Shot", obj4);
        objSkills.gets("Bomb Throw", obj2);
        objSkills.gets("Rocket Launcher", obj4);
        objSkills.gets("Healing System", obj4);

//        obj4.addSameThings(objMaterials.get("Iron Ore"), 5);
//        obj4.addSameThings(objMaterials.get("Copper"), 4);
//        obj4.addThing(objSkills.get("Laser Shot"));
//        obj4.addThing(objSkills.get("Bomb Throw"));
//        obj4.addThing(objSkills.get("Rocket Launcher"));
//        obj4.addThing(objSkills.get("Healing System"));

        objMaterials.gets("Iron Ore", 6, obj5);
        objMaterials.gets("Copper", 7, obj5);
        objMaterials.gets("Gold", 1, obj5);
        objSkills.gets("Laser Shot", obj5);
        objSkills.gets("Bomb Throw", obj5);
        objSkills.gets("Rocket Launcher", obj5);
        objSkills.gets("Healing System", obj5);

//        obj5.addSameThings(objMaterials.get("Iron Ore"), 6);
//        obj5.addSameThings(objMaterials.get("Copper"), 7);
//        obj5.addThing(objMaterials.get("Gold"));
//        obj5.addThing(objSkills.get("Laser Shot"));
//        obj5.addThing(objSkills.get("Bomb Throw"));
//        obj5.addThing(objSkills.get("Rocket Launcher"));
//        obj5.addThing(objSkills.get("Healing System"));

        objMaterials.gets("Iron Ore", 7, obj6);
        objMaterials.gets("Copper", 7, obj6);
        objMaterials.gets("Onyx", 1, obj6);
        objSkills.gets("Laser Shot", obj6);
        objSkills.gets("Bomb Throw", obj6);
        objSkills.gets("Rocket Launcher", obj6);
        objSkills.gets("Healing System", obj6);

//        obj6.addSameThings(objMaterials.get("Iron Ore"), 7);
//        obj6.addSameThings(objMaterials.get("Copper"), 7);
//        obj6.addThing(objMaterials.get("Onyx"));
//        obj6.addThing(objSkills.get("Laser Shot"));
//        obj6.addThing(objSkills.get("Bomb Throw"));
//        obj6.addThing(objSkills.get("Rocket Launcher"));
//        obj6.addThing(objSkills.get("Healing System"));

        objMaterials.gets("Iron Ore", 3, obj7);
        objMaterials.gets("Copper", 2, obj7);
        objMaterials.gets("Gold", 4, obj7);
        objSkills.gets("Laser Shot", obj7);
        objSkills.gets("Bomb Throw", obj7);
        objSkills.gets("Rocket Launcher", obj7);
        objSkills.gets("Healing System", obj7);
        objSkills.gets("Engine Recovery", obj7);

//        obj7.addSameThings(objMaterials.get("Iron Ore"), 3);
//        obj7.addSameThings(objMaterials.get("Copper"), 2);
//        obj7.addSameThings(objMaterials.get("Gold"), 4);
//        obj7.addThing(objSkills.get("Laser Shot"));
//        obj7.addThing(objSkills.get("Bomb Throw"));
//        obj7.addThing(objSkills.get("Rocket Launcher"));
//        obj7.addThing(objSkills.get("Healing System"));
//        obj7.addThing(objSkills.get("Engine Recovery"));

        objMaterials.gets("Iron Ore", 2, obj8);
        objMaterials.gets("Copper", 4, obj8);
        objMaterials.gets("Onyx", 5, obj8);
        objSkills.gets("Laser Shot", obj8);
        objSkills.gets("Bomb Throw", obj8);
        objSkills.gets("Rocket Launcher", obj8);
        objSkills.gets("Healing System", obj8);
        objSkills.gets("Engine Recovery", obj8);

//        obj8.addSameThings(objMaterials.get("Iron Ore"), 2);
//        obj8.addSameThings(objMaterials.get("Copper"), 4);
//        obj8.addSameThings(objMaterials.get("Onyx"), 5);
//        obj8.addThing(objSkills.get("Laser Shot"));
//        obj8.addThing(objSkills.get("Bomb Throw"));
//        obj8.addThing(objSkills.get("Rocket Launcher"));
//        obj8.addThing(objSkills.get("Healing System"));
//        obj8.addThing(objSkills.get("Engine Recovery"));

        objMaterials.gets("Animal Skin", 3, obj9);
        objSkills.gets("Death Claw", obj9);
        objSkills.gets("Head Butting", obj9);
        objSkills.gets("Claw and Bite", obj9);

//        obj9.addSameThings(objMaterials.get("Animal Skin"), 3);
//        obj9.addThing(objSkills.get("Death Claw"));
//        obj9.addThing(objSkills.get("Head Butting"));
//        obj9.addThing(objSkills.get("Claw and Bite"));

        objMaterials.gets("Animal Skin", 4, obj10);
        objSkills.gets("Death Claw", obj10);
        objSkills.gets("Head Butting", obj10);
        objSkills.gets("Claw and Bite", obj10);

//        obj10.addSameThings(objMaterials.get("Animal Skin"), 4);
//        obj10.addThing(objSkills.get("Death Claw"));
//        obj10.addThing(objSkills.get("Head Butting"));
//        obj10.addThing(objSkills.get("Claw and Bite"));

        objMaterials.gets("Animal Skin", 3, obj11);
        objSkills.gets("Death Claw", obj11);
        objSkills.gets("Head Butting", obj11);
        objSkills.gets("Claw and Bite", obj11);

//        obj11.addSameThings(objMaterials.get("Animal Skin"), 3);
//        obj11.addThing(objSkills.get("Death Claw"));
//        obj11.addThing(objSkills.get("Head Butting"));
//        obj11.addThing(objSkills.get("Claw and Bite"));

        objMaterials.gets("Agate", 2, obj12);
        objMaterials.gets("Quartz", 3, obj12);
        objSkills.gets("Laser Targeting", obj12);
        objSkills.gets("Sword Bash", obj12);
        objSkills.gets("Healing Armor", obj12);

//        obj12.addSameThings(objMaterials.get("Agate"), 2);
//        obj12.addSameThings(objMaterials.get("Quartz"), 3);
//        obj12.addThing(objSkills.get("Laser Targeting"));
//        obj12.addThing(objSkills.get("Sword Bash"));
//        obj12.addThing(objSkills.get("Healing Armor"));

        objMaterials.gets("Zicron", 3, obj13);
        objMaterials.gets("Safir", 4, obj13);
        objSkills.gets("Laser Targeting", obj13);
        objSkills.gets("Sword Bash", obj13);
        objSkills.gets("Healing Armor", obj13);
        objSkills.gets("Flying Rocket", obj13);
        objSkills.gets("Body Recovery", obj13);

//        obj13.addSameThings(objMaterials.get("Zicron"), 3);
//        obj13.addSameThings(objMaterials.get("Safir"), 4);
//        obj13.addThing(objSkills.get("Laser Targeting"));
//        obj13.addThing(objSkills.get("Sword Bash"));
//        obj13.addThing(objSkills.get("Healing Armor"));
//        obj13.addThing(objSkills.get("Flying Rocket"));
//        obj13.addThing(objSkills.get("Body Recovery"));

        objMaterials.gets("Diamond", 3, obj14);
        objMaterials.gets("Zicron", 2, obj14);
        objMaterials.gets("Jasper", 1, obj14);
        objSkills.gets("Laser Targeting", obj14);
        objSkills.gets("Sword Bash", obj14);
        objSkills.gets("Healing Armor", obj14);
        objSkills.gets("Flying Rocket", obj14);
        objSkills.gets("Body Recovery", obj14);

//        obj14.addSameThings(objMaterials.get("Diamond"), 3);
//        obj14.addSameThings(objMaterials.get("Zicron"), 2);
//        obj14.addThing(objMaterials.get("Jasper"));
//        obj14.addThing(objSkills.get("Laser Targeting"));
//        obj14.addThing(objSkills.get("Sword Bash"));
//        obj14.addThing(objSkills.get("Healing Armor"));
//        obj14.addThing(objSkills.get("Flying Rocket"));
//        obj14.addThing(objSkills.get("Body Recovery"));

        objMaterials.gets("Safir", 4, obj15);
        objMaterials.gets("Diamond", 2, obj15);
        objMaterials.gets("Garnet", 1, obj14);
        objSkills.gets("Laser Targeting", obj15);
        objSkills.gets("Sword Bash", obj15);
        objSkills.gets("Healing Armor", obj15);
        objSkills.gets("Flying Rocket", obj15);
        objSkills.gets("Body Recovery", obj15);

//        obj15.addSameThings(objMaterials.get("Safir"), 4);
//        obj15.addSameThings(objMaterials.get("Diamond"), 2);
//        obj15.addThing(objMaterials.get("Garnet"));
//        obj15.addThing(objSkills.get("Laser Targeting"));
//        obj15.addThing(objSkills.get("Sword Bash"));
//        obj15.addThing(objSkills.get("Healing Armor"));
//        obj15.addThing(objSkills.get("Flying Rocket"));
//        obj15.addThing(objSkills.get("Body Recovery"));

        objMaterials.gets("Platinum", 1, obj16);
        objMaterials.gets("Garnet", 1, obj16);
        objMaterials.gets("Jasper", 1, obj16);
        objSkills.gets("Guide to Afterlife", obj16);
        objSkills.gets("Foul Legacy", obj16);
        objSkills.gets("Starfell Sword", obj16);
        objSkills.gets("Twilight Armort", obj16);
        objSkills.gets("Dominus Shield Lapidis", obj16);

//        obj16.addThing(objMaterials.get("Platinum"));
//        obj16.addThing(objMaterials.get("Garnet"));
//        obj16.addThing(objMaterials.get("Jasper"));
//        obj16.addThing(objSkills.get("Guide to Afterlife"));
//        obj16.addThing(objSkills.get("Foul Legacy"));
//        obj16.addThing(objSkills.get("Starfell Sword"));
//        obj16.addThing(objSkills.get("Twilight Armor"));
//        obj16.addThing(objSkills.get("Dominus Shield Lapidis"));

        objMaterials.gets("Iron Ore", 2, obj17);
        objSkills.gets("Laser Shot", obj17);
        objSkills.gets("Bomb Throw", obj17);

//        obj17.addSameThings(objMaterials.get("Iron Ore"), 2);
//        obj17.addThing(objSkills.get("Laser Shot"));
//        obj17.addThing(objSkills.get("Bomb Throw"));

        objMaterials.gets("Copper", 2, obj18);
        objSkills.gets("Laser Shot", obj18);
        objSkills.gets("Bomb Throw", obj18);

//        obj18.addSameThings(objMaterials.get("Copper"), 2);
//        obj18.addThing(objSkills.get("Laser Shot"));
//        obj18.addThing(objSkills.get("Bomb Throw"));

        objMaterials.gets("Iron Ore", 3, obj17);
        objSkills.gets("Laser Shot", obj17);
        objSkills.gets("Bomb Throw", obj17);

//        obj19.addSameThings(objMaterials.get("Iron Ore"), 3);
//        obj19.addThing(objSkills.get("Laser Shot"));
//        obj19.addThing(objSkills.get("Bomb Throw"));

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
        cache.put(obj11.getName(), obj11);
        cache.put(obj12.getName(), obj12);
        cache.put(obj13.getName(), obj13);
        cache.put(obj14.getName(), obj14);
        cache.put(obj15.getName(), obj15);
        cache.put(obj16.getName(), obj16);
        cache.put(obj17.getName(), obj17);
        cache.put(obj18.getName(), obj18);
        cache.put(obj19.getName(), obj19);
    }
}
