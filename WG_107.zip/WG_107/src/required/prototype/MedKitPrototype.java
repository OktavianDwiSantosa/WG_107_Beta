package required.prototype;

import main.item.MedKit;
import required.Item;
import required.Thing;
import required.enums.RarityType;
import required.multipliers.Health;

public class MedKitPrototype extends BundledPrototype {
    public MedKitPrototype() {
        MedKit obj1 = new MedKit("Binder", "A small repairing kit",
                50, RarityType.COMMON, new Health(0.25));
        MedKit obj2 = new MedKit("Mender", "A medium repairing kit",
                50, RarityType.COMMON, new Health(0.5));
        MedKit obj3 = new MedKit("Xander", "A large repairing kit",
                100, RarityType.RARE, new Health(1));

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
    }

    public void gets(String vName, int vAmount, Thing vOwner) throws CloneNotSupportedException {
        for (int i = 0; i < vAmount; i++) ((Item) get(vName)).moveTo(vOwner);
    }
}
