package required.prototype;

import main.Box;

public class BoxPrototype extends BundledPrototype {
    public BoxPrototype() {
        Box obj1 = new Box("Common Supply", "Ordinary supply box", 10);
        Box obj2 = new Box("Exquisite Supply", "Stunning exquisite supply box", 30);
        Box obj3 = new Box("Luxurious Supply", "Luxurious and charming supply box", 100);
        Box obj4 = new Box("Wooden Barrel", "Fragile wooden barrel", 2);
        Box obj5 = new Box("Wooden Box", "Fragile wooden box", 5);

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
    }
}
