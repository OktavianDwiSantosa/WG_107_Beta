package required.prototype;

import main.item.Weapon;
import required.Item;
import required.Thing;
import required.builders.equipment.EquipmentBuilders;
import required.enums.RarityType;
import required.enums.WeaponType;

public class WeaponPrototype extends BundledPrototype {
    public WeaponPrototype() {
        Weapon obj1 = EquipmentBuilders.newWeapon()
                .name("Thalassa")
                .description("A heavy sword from Thales")
                .price(300)
                .rarity(RarityType.COMMON)
                .level(1)
                .weaponType(WeaponType.SWORD)
                .strengthMultiplier(0.133)
                .shieldMultiplier(0.058)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Copper", 2)
                .build();

        Weapon obj2 = EquipmentBuilders.newWeapon()
                .name("Persuader")
                .description("A sword made by a blacksmith elder")
                .price(600)
                .rarity(RarityType.RARE)
                .level(1)
                .weaponType(WeaponType.SWORD)
                .strengthMultiplier(0.184)
                .shieldMultiplier(0.098)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Gold", 1)
                .build();

        Weapon obj3 = EquipmentBuilders.newWeapon()
                .name("Greedy Longsword")
                .description("A expensive and epic longsword")
                .price(1200)
                .rarity(RarityType.EPIC)
                .level(1)
                .weaponType(WeaponType.SWORD)
                .strengthMultiplier(0.237)
                .shieldMultiplier(0.153)
                .requiredMaterials("Diamond", 2)
                .requiredMaterials("Agate", 2)
                .build();

        Weapon obj4 = EquipmentBuilders.newWeapon()
                .name("Sword of Exile")
                .description("A sword that was exiled for being too strong")
                .price(2400)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .weaponType(WeaponType.SWORD)
                .strengthMultiplier(0.283)
                .shieldMultiplier(0.209)
                .requiredMaterials("Zicron", 2)
                .requiredMaterials("Platinum", 1)
                .build();

        Weapon obj5 = EquipmentBuilders.newWeapon()
                .name("Mended Revolver")
                .description("A pretty lethal gun")
                .price(300)
                .rarity(RarityType.COMMON)
                .level(1)
                .weaponType(WeaponType.PROJECTILE)
                .strengthMultiplier(0.303)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Copper", 2)
                .build();

        Weapon obj6 = EquipmentBuilders.newWeapon()
                .name("Furious Repeater")
                .description("A red hot automatic gun")
                .price(600)
                .rarity(RarityType.RARE)
                .level(1)
                .weaponType(WeaponType.PROJECTILE)
                .strengthMultiplier(0.358)
                .requiredMaterials("Copper", 3)
                .requiredMaterials("Onyx", 1)
                .build();

        Weapon obj7 = EquipmentBuilders.newWeapon()
                .name("Apollo Slingshot")
                .description("A deadly little gun")
                .price(1200)
                .rarity(RarityType.EPIC)
                .level(1)
                .weaponType(WeaponType.PROJECTILE)
                .strengthMultiplier(0.412)
                .requiredMaterials("Safir", 2)
                .requiredMaterials("Quartz", 2)
                .build();

        Weapon obj8 = EquipmentBuilders.newWeapon()
                .name("Hellsgun")
                .description("A fierce and terrifying gun")
                .price(2400)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .weaponType(WeaponType.PROJECTILE)
                .strengthMultiplier(0.512)
                .requiredMaterials("Agate", 2)
                .requiredMaterials("Garnet", 1)
                .build();

        Weapon obj9 = EquipmentBuilders.newWeapon()
                .name("Toasty Gauntlet")
                .description("A smoldering gauntlet")
                .price(300)
                .rarity(RarityType.COMMON)
                .level(1)
                .weaponType(WeaponType.GAUNTLET)
                .strengthMultiplier(0.072)
                .shieldMultiplier(0.164)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Copper", 2)
                .build();

        Weapon obj10 = EquipmentBuilders.newWeapon()
                .name("Ares Spike")
                .description("A gauntlet full of thorns")
                .price(600)
                .rarity(RarityType.RARE)
                .level(1)
                .weaponType(WeaponType.GAUNTLET)
                .strengthMultiplier(0.184)
                .shieldMultiplier(0.098)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Onyx", 1)
                .build();

        Weapon obj11 = EquipmentBuilders.newWeapon()
                .name("Baneful Grips")
                .description("A sturdy and strong gauntlet")
                .price(1200)
                .rarity(RarityType.EPIC)
                .level(1)
                .weaponType(WeaponType.GAUNTLET)
                .strengthMultiplier(0.237)
                .shieldMultiplier(0.153)
                .requiredMaterials("Diamond", 2)
                .requiredMaterials("Safir", 2)
                .build();

        Weapon obj12 = EquipmentBuilders.newWeapon()
                .name("Warlord Grasp")
                .description("A legendary warlord relic gauntlet")
                .price(2400)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .weaponType(WeaponType.GAUNTLET)
                .strengthMultiplier(0.283)
                .shieldMultiplier(0.209)
                .requiredMaterials("Quartz", 2)
                .requiredMaterials("Jasper", 1)
                .build();

        Weapon obj13 = EquipmentBuilders.newWeapon()
                .name("Honed Scimitar")
                .description("A dangerous saber")
                .price(300)
                .rarity(RarityType.COMMON)
                .level(1)
                .weaponType(WeaponType.SABER)
                .strengthMultiplier(0.214)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Copper", 2)
                .build();

        Weapon obj14 = EquipmentBuilders.newWeapon()
                .name("Kriegsmesser")
                .description("A crude and brutal saber")
                .price(600)
                .rarity(RarityType.RARE)
                .level(1)
                .weaponType(WeaponType.SABER)
                .strengthMultiplier(0.267)
                .requiredMaterials("Copper", 3)
                .requiredMaterials("Gold", 1)
                .build();

        Weapon obj15 = EquipmentBuilders.newWeapon()
                .name("Dancing Dao")
                .description("An enchanting saber")
                .price(1200)
                .rarity(RarityType.EPIC)
                .level(1)
                .weaponType(WeaponType.SABER)
                .strengthMultiplier(0.328)
                .requiredMaterials("Zicron", 2)
                .requiredMaterials("Agate", 2)
                .build();

        Weapon obj16 = EquipmentBuilders.newWeapon()
                .name("Sinister Katana")
                .description("A sharp and deadly saber")
                .price(2400)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .weaponType(WeaponType.SABER)
                .strengthMultiplier(0.389)
                .requiredMaterials("Diamond", 2)
                .requiredMaterials("Platinum", 1)
                .build();

        Weapon obj17 = EquipmentBuilders.newWeapon()
                .name("Altering Cluster")
                .description("A unique and powerful cyberware")
                .price(300)
                .rarity(RarityType.COMMON)
                .level(1)
                .weaponType(WeaponType.CYBERWARE)
                .strengthMultiplier(0.92)
                .shieldMultiplier(0.124)
                .healthMultiplier(0.112)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Copper", 2)
                .build();

        Weapon obj18 = EquipmentBuilders.newWeapon()
                .name("Neurorectifier")
                .description("A cyberware that affects the nervous system")
                .price(600)
                .rarity(RarityType.RARE)
                .level(1)
                .weaponType(WeaponType.CYBERWARE)
                .strengthMultiplier(0.145)
                .shieldMultiplier(0.181)
                .healthMultiplier(0.177)
                .requiredMaterials("Iron Ore", 3)
                .requiredMaterials("Onyx", 1)
                .build();

        Weapon obj19 = EquipmentBuilders.newWeapon()
                .name("Electro Rectifier")
                .description("A cyberware that amplifies electric current")
                .price(1200)
                .rarity(RarityType.EPIC)
                .level(1)
                .weaponType(WeaponType.CYBERWARE)
                .strengthMultiplier(0.203)
                .shieldMultiplier(0.213)
                .healthMultiplier(0.207)
                .requiredMaterials("Diamond", 2)
                .requiredMaterials("Safir", 2)
                .build();

        Weapon obj20 = EquipmentBuilders.newWeapon()
                .name("Myosnare")
                .description("A cyberware that traps its prey")
                .price(2400)
                .rarity(RarityType.LEGENDARY)
                .level(1)
                .weaponType(WeaponType.CYBERWARE)
                .strengthMultiplier(0.252)
                .shieldMultiplier(0.244)
                .healthMultiplier(0.247)
                .requiredMaterials("Safir", 2)
                .requiredMaterials("Jasper", 1)
                .build();

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
        cache.put(obj11.getName(), obj11);
        cache.put(obj12.getName(), obj12);
        cache.put(obj13.getName(), obj13);
        cache.put(obj14.getName(), obj14);
        cache.put(obj15.getName(), obj15);
        cache.put(obj16.getName(), obj16);
        cache.put(obj17.getName(), obj17);
        cache.put(obj18.getName(), obj18);
        cache.put(obj19.getName(), obj19);
        cache.put(obj20.getName(), obj20);
    }

    public void gets(String vName, Thing vOwner) throws CloneNotSupportedException {
        ((Item) get(vName)).moveTo(vOwner);
    }
}
