package required.prototype;

import main.Skill;
import required.Item;
import required.Thing;
import required.builders.skill.SkillBuilders;
import required.enums.SkillType;

public class SkillPrototype extends BundledPrototype {
    public SkillPrototype() {
        // Elon
        Skill obj1 = new SkillBuilders()
                .name("Wind Blade")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(5)
                .strengthMultiplier(0.1)
                .build();

        Skill obj2 = new SkillBuilders()
                .name("Coldwind Slash")
                .unlockedLevel(3)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.15)
                .build();

        Skill obj3 = new SkillBuilders()
                .name("Implosion")
                .unlockedLevel(9)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(15)
                .strengthMultiplier(0.175)
                .build();

        Skill obj4 = new SkillBuilders()
                .name("Blade of Shapire")
                .unlockedLevel(15)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.135)
                .build();

        Skill obj5 = new SkillBuilders()
                .name("Endless Battle")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(45)
                .strengthMultiplier(0.25)
                .build();

        Skill obj6 = new SkillBuilders()
                .name("Revitalize")
                .unlockedLevel(3)
                .skillType(SkillType.LIGHT)
                .targetFoe(false)
                .timestamp(5)
                .healthMultiplier(0.1)
                .shieldMultiplier(0.05)
                .build();

        Skill obj7 = new SkillBuilders()
                .name("Oracle")
                .unlockedLevel(20)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.225)
                .shieldMultiplier(0.125)
                .build();

        // Farlan
        Skill obj8 = new SkillBuilders()
                .name("Tiger Pounce")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(5)
                .strengthMultiplier(0.1)
                .build();

        Skill obj9 = new SkillBuilders()
                .name("Soulbreak")
                .unlockedLevel(3)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.15)
                .build();

        Skill obj10 = new SkillBuilders()
                .name("Shadow Eruption")
                .unlockedLevel(10)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(15)
                .strengthMultiplier(0.175)
                .build();

        Skill obj11 = new SkillBuilders()
                .name("Rose Gold")
                .unlockedLevel(15)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.135)
                .build();

        Skill obj12 = new SkillBuilders()
                .name("Fierce Strike")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(35)
                .strengthMultiplier(0.25)
                .build();

        Skill obj13 = new SkillBuilders()
                .name("Aegis")
                .unlockedLevel(3)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.185)
                .shieldMultiplier(0.105)
                .build();

        Skill obj14 = new SkillBuilders()
                .name("Thunder Belt")
                .unlockedLevel(20)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.245)
                .shieldMultiplier(0.125)
                .build();

        Skill obj15 = new SkillBuilders()
                .name("Black Ice Shield")
                .unlockedLevel(25)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.225)
                .shieldMultiplier(0.165)
                .build();

        // Jojo
        Skill obj16 = new SkillBuilders()
                .name("Shadowhand")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.1)
                .build();

        Skill obj17 = new SkillBuilders()
                .name("Dark Knight")
                .unlockedLevel(4)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.15)
                .build();

        Skill obj18 = new SkillBuilders()
                .name("Dark Pulse")
                .unlockedLevel(10)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(20)
                .strengthMultiplier(0.175)
                .build();

        Skill obj19 = new SkillBuilders()
                .name("Windtalker")
                .unlockedLevel(16)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(25)
                .strengthMultiplier(0.195)
                .build();

        Skill obj20 = new SkillBuilders()
                .name("Predatory Hunt")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(40)
                .strengthMultiplier(0.325)
                .build();

        Skill obj21 = new SkillBuilders()
                .name("Guardian Helmet")
                .unlockedLevel(14)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.165)
                .shieldMultiplier(0.115)
                .build();

        Skill obj22 = new SkillBuilders()
                .name("Dreadnought Armor")
                .unlockedLevel(20)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.185)
                .shieldMultiplier(0.135)
                .build();

        // Raikou
        Skill obj23 = new SkillBuilders()
                .name("Slaughter Ring")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.1)
                .build();

        Skill obj24 = new SkillBuilders()
                .name("Illusion")
                .unlockedLevel(4)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.15)
                .build();

        Skill obj25 = new SkillBuilders()
                .name("Soul Siphon")
                .unlockedLevel(10)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(15)
                .strengthMultiplier(0.175)
                .build();

        Skill obj26 = new SkillBuilders()
                .name("Headbutt")
                .unlockedLevel(15)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.135)
                .build();

        Skill obj27 = new SkillBuilders()
                .name("Ultimate Thunderstorms")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(45)
                .strengthMultiplier(0.45)
                .build();

        Skill obj28 = new SkillBuilders()
                .name("Regen")
                .unlockedLevel(5)
                .skillType(SkillType.LIGHT)
                .targetFoe(false)
                .timestamp(5)
                .healthMultiplier(0.225)
                .shieldMultiplier(0.125)
                .build();

        Skill obj29 = new SkillBuilders()
                .name("Blade Armor")
                .unlockedLevel(24)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(15)
                .healthMultiplier(0.245)
                .shieldMultiplier(0.125)
                .build();

        Skill obj30 = new SkillBuilders()
                .name("Athena Shield")
                .unlockedLevel(28)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(20)
                .healthMultiplier(0.225)
                .shieldMultiplier(0.165)
                .build();

        // Tony
        Skill obj31 = new SkillBuilders()
                .name("Frozen Blade")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.1)
                .build();

        Skill obj32 = new SkillBuilders()
                .name("Demon Blade")
                .unlockedLevel(4)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.15)
                .build();

        Skill obj33 = new SkillBuilders()
                .name("Wrath of Chaos")
                .unlockedLevel(10)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(15)
                .strengthMultiplier(0.175)
                .build();

        Skill obj34 = new SkillBuilders()
                .name("Blade Phantom")
                .unlockedLevel(15)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(10)
                .strengthMultiplier(0.185)
                .build();

        Skill obj35 = new SkillBuilders()
                .name("Fire Chaos")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(45)
                .strengthMultiplier(0.425)
                .build();

        Skill obj36 = new SkillBuilders()
                .name("Immortality")
                .unlockedLevel(10)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.115)
                .shieldMultiplier(0.125)
                .build();

        Skill obj37 = new SkillBuilders()
                .name("Ares Belt")
                .unlockedLevel(22)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(10)
                .healthMultiplier(0.165)
                .shieldMultiplier(0.145)
                .build();

        Skill obj38 = new SkillBuilders()
                .name("Vitality Crystal")
                .unlockedLevel(24)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(15)
                .healthMultiplier(0.245)
                .shieldMultiplier(0.195)
                .build();

        // Droids
        Skill obj39 = new SkillBuilders()
                .name("Laser Shot")
                .unlockedLevel(1)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(25)
                .strengthMultiplier(0.1)
                .build();

        Skill obj40 = new SkillBuilders()
                .name("Bomb Throw")
                .unlockedLevel(1)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(35)
                .strengthMultiplier(0.165)
                .build();

        Skill obj41 = new SkillBuilders()
                .name("Rocket Launcher")
                .unlockedLevel(1)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(50)
                .strengthMultiplier(0.325)
                .build();

        Skill obj42 = new SkillBuilders()
                .name("Healing System")
                .unlockedLevel(4)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(20)
                .healthMultiplier(0.185)
                .shieldMultiplier(0.135)
                .build();

        Skill obj43 = new SkillBuilders()
                .name("Engine Recovery")
                .unlockedLevel(10)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(35)
                .healthMultiplier(0.35)
                .shieldMultiplier(0.185)
                .build();

        // Animals
        Skill obj44 = new SkillBuilders()
                .name("Death Claw")
                .unlockedLevel(15)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(25)
                .strengthMultiplier(0.175)
                .build();

        Skill obj45 = new SkillBuilders()
                .name("Head Butting")
                .unlockedLevel(15)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(35)
                .strengthMultiplier(0.235)
                .build();

        Skill obj46 = new SkillBuilders()
                .name("Claw and Bite")
                .unlockedLevel(15)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(45)
                .strengthMultiplier(0.325)
                .build();

        // Tower Guards
        Skill obj47 = new SkillBuilders()
                .name("Laser Targeting")
                .unlockedLevel(20)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(20)
                .strengthMultiplier(0.165)
                .build();

        Skill obj48 = new SkillBuilders()
                .name("Sword Bash")
                .unlockedLevel(21)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(25)
                .strengthMultiplier(0.245)
                .build();

        Skill obj49 = new SkillBuilders()
                .name("Flying Rocket")
                .unlockedLevel(22)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(50)
                .strengthMultiplier(0.375)
                .build();

        Skill obj50 = new SkillBuilders()
                .name("Healing Armor")
                .unlockedLevel(21)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(20)
                .healthMultiplier(0.175)
                .shieldMultiplier(0.135)
                .build();

        Skill obj51 = new SkillBuilders()
                .name("Body Recovery")
                .unlockedLevel(22)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(35)
                .healthMultiplier(0.265)
                .shieldMultiplier(0.195)
                .build();

        // Cube Inc General
        Skill obj52 = new SkillBuilders()
                .name("Guide to Afterlife")
                .unlockedLevel(30)
                .skillType(SkillType.LIGHT)
                .targetFoe(true)
                .timestamp(20)
                .strengthMultiplier(0.155)
                .build();

        Skill obj53 = new SkillBuilders()
                .name("Foul Legacy")
                .unlockedLevel(30)
                .skillType(SkillType.NORMAL)
                .targetFoe(true)
                .timestamp(35)
                .strengthMultiplier(0.25)
                .build();

        Skill obj54 = new SkillBuilders()
                .name("Starfell Sword")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(true)
                .timestamp(45)
                .strengthMultiplier(0.5)
                .build();

        Skill obj55 = new SkillBuilders()
                .name("Twilight Armor")
                .unlockedLevel(30)
                .skillType(SkillType.NORMAL)
                .targetFoe(false)
                .timestamp(25)
                .healthMultiplier(0.2)
                .shieldMultiplier(0.135)
                .build();

        Skill obj56 = new SkillBuilders()
                .name("Dominus Shield Lapidis")
                .unlockedLevel(30)
                .skillType(SkillType.HEAVY)
                .targetFoe(false)
                .timestamp(50)
                .healthMultiplier(0.425)
                .shieldMultiplier(0.275)
                .build();

        cache.put(obj1.getName(), obj1);
        cache.put(obj2.getName(), obj2);
        cache.put(obj3.getName(), obj3);
        cache.put(obj4.getName(), obj4);
        cache.put(obj5.getName(), obj5);
        cache.put(obj6.getName(), obj6);
        cache.put(obj7.getName(), obj7);
        cache.put(obj8.getName(), obj8);
        cache.put(obj9.getName(), obj9);
        cache.put(obj10.getName(), obj10);
        cache.put(obj11.getName(), obj11);
        cache.put(obj12.getName(), obj12);
        cache.put(obj13.getName(), obj13);
        cache.put(obj14.getName(), obj14);
        cache.put(obj15.getName(), obj15);
        cache.put(obj16.getName(), obj16);
        cache.put(obj17.getName(), obj17);
        cache.put(obj18.getName(), obj18);
        cache.put(obj19.getName(), obj19);
        cache.put(obj20.getName(), obj20);
        cache.put(obj21.getName(), obj21);
        cache.put(obj22.getName(), obj22);
        cache.put(obj23.getName(), obj23);
        cache.put(obj24.getName(), obj24);
        cache.put(obj25.getName(), obj25);
        cache.put(obj26.getName(), obj26);
        cache.put(obj27.getName(), obj27);
        cache.put(obj28.getName(), obj28);
        cache.put(obj29.getName(), obj29);
        cache.put(obj30.getName(), obj30);
        cache.put(obj31.getName(), obj31);
        cache.put(obj32.getName(), obj32);
        cache.put(obj33.getName(), obj33);
        cache.put(obj34.getName(), obj34);
        cache.put(obj35.getName(), obj35);
        cache.put(obj36.getName(), obj36);
        cache.put(obj37.getName(), obj37);
        cache.put(obj38.getName(), obj38);
        cache.put(obj39.getName(), obj39);
        cache.put(obj40.getName(), obj40);
        cache.put(obj41.getName(), obj41);
        cache.put(obj42.getName(), obj42);
        cache.put(obj43.getName(), obj43);
        cache.put(obj44.getName(), obj44);
        cache.put(obj45.getName(), obj45);
        cache.put(obj46.getName(), obj46);
        cache.put(obj47.getName(), obj47);
        cache.put(obj48.getName(), obj48);
        cache.put(obj49.getName(), obj49);
        cache.put(obj50.getName(), obj50);
        cache.put(obj51.getName(), obj51);
        cache.put(obj52.getName(), obj52);
        cache.put(obj53.getName(), obj53);
        cache.put(obj54.getName(), obj54);
        cache.put(obj55.getName(), obj55);
        cache.put(obj56.getName(), obj56);
    }

    public void gets(String vName, Thing vOwner) throws CloneNotSupportedException {
        ((Item) get(vName)).moveTo(vOwner);
    }
}
