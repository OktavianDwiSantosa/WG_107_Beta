package required.prototype;

import required.Thing;

import java.util.HashMap;

public abstract class BundledPrototype {
    protected final HashMap<String, Thing> cache = new HashMap<>();

    public void put(String key, Thing vThing) {
        cache.put(key, vThing);
    }

    public Thing get(String key) throws CloneNotSupportedException {
        return (Thing) cache.get(key).clone();
    }
}
