package required;

import main.GameInfo;
import main.Hero;
import main.item.Material;
import required.enums.ModifiedType;
import required.enums.Operator;
import required.enums.RarityType;
import required.multipliers.Multiplier;

import java.util.ArrayList;
import java.util.HashMap;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;

// https://refactoring.guru/design-patterns/visitor
// https://refactoring.guru/design-patterns/visitor-double-dispatch

// TODO : buat method untuk memilah Equipment berdasarkan Type
// https://refactoring.guru/design-patterns/builder/java/example

public abstract class Equipment extends Item {
    private boolean isEquip; // Item sedang dipakai?
    private int level; // level --> 1 - 5
    private int upgradeCost;

    // nilai-nilai pengali strength, health & shield
    private ArrayList<Multiplier> multipliers;
    // nama & jumlah Material yang diperlukan untuk upgrade
    private HashMap<String, Integer> requiredMaterials;

    // Constructor
    public Equipment(String vName, String vDescription, Thing vOwner,
                     int vPrice, RarityType vRarity, int vLevel,
                     ArrayList<Multiplier> vMultipliers,
                     HashMap<String, Integer> vRequiredMaterials) {
        super(vName, vDescription, vOwner, vPrice, vRarity);
        if (vOwner instanceof Hero) {
            equipped((Hero) vOwner);
        } else if (vOwner != null) {
            moveTo(vOwner);
        }
        level = vLevel;
        upgradeCost = (int) (vPrice * 1.2);
        multipliers = vMultipliers;
        requiredMaterials = vRequiredMaterials;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Equipment newClone = (Equipment) super.clone();
        deepCloneMultipliers(newClone, this.multipliers);
        newClone.requiredMaterials = new HashMap<>(this.requiredMaterials);
        return newClone;
    }

    protected void deepCloneMultipliers(Equipment newClone, ArrayList<Multiplier> oldMultipliers)
            throws CloneNotSupportedException {
        newClone.multipliers = new ArrayList<>();
        for (Multiplier vMultiplier : oldMultipliers)
            newClone.multipliers.add((Multiplier) vMultiplier.clone());
    }

    // Method
    @Override
    public void describe() {
        super.describe();
        System.out.println(getTrueClassName() + " Level : " + level);
        multipliers.forEach(Multiplier::printProbability);
    }

    public void equipped(Hero vNewOwner) {
        if (!isEquip) {
            calcOwnerFields(Operator.ADDITION, vNewOwner);
            switchOwner(vNewOwner);
            isEquip = true;
        }
    }

    public void unequipped() {
        if (isEquip) {
            calcOwnerFields(Operator.SUBTRACTION, (Hero) getOwner());
            switchOwner(GameInfo.userInventory);
            isEquip = false;
        }
    }

    @Override
    public boolean modified(ModifiedType vModifiedType) {
        if (!super.modified(vModifiedType)) { // jika gagal menjual atau membeli item
            if (vModifiedType == ModifiedType.UPGRADE
                    || vModifiedType == ModifiedType.CRAFT) {
                addMaterials();
                int cost;

                if (vModifiedType == ModifiedType.UPGRADE) {
                    cost = upgradeCost;
                } else {
                    cost = (int) (getPrice() * 0.5);
                }

                if (GameInfo.userInventory.getAxel() >= cost
                        && countMaterials() == requiredMaterials.size()) {
                    if (vModifiedType == ModifiedType.UPGRADE && level < 5) {
                        increaseLevelAndCost();
                        return true;
                    } else if (vModifiedType == ModifiedType.CRAFT) {
                        useMaterials();
                        return true;
                    }
                }

                returnMaterials();
                return false;
            }
            return false; // jika gagal karena syarat pembelian atau penjualan tidak terpenuhi
        }
        return true; // karena syarat pembelian atau penjualan sudah terpenuhi
    }

    private void increaseLevelAndCost() {
        level += 1; // urutan langkah ini diperlukan untuk upgrade
        upgradeCost += (int) (upgradeCost * (level * 0.2)); // rumus upgrade
        useMaterials();
    }

    public void calcOwnerFields(Operator vOp, Figure vOwner) {
        multipliers.forEach(multiplier -> multiplier.applyEqValue(vOp, vOwner));
    }

    public void addMaterials() { // tambahkan objek-objek Material yang diperlukan
        for (String requiredMaterial : requiredMaterials.keySet())
            for (Thing objMaterial : GameInfo.userInventory.getOneClass("Material"))
                if (objMaterial.getName().equals(requiredMaterial))
                    ((Material) objMaterial).moveTo(this);
    }

    public void useMaterials() { // used setiap objek Material
        for (String requiredMaterial : requiredMaterials.keySet()) {
            // jumlah objek Material yang dibutuhkan untuk modified
            int remainingMaterial = requiredMaterials.get(requiredMaterial);

            // update jumlah material yang dibutuhkan untuk upgrade selanjutnya
            requiredMaterials.put(requiredMaterial, (remainingMaterial * 2));

            for (Thing objMaterial : getArrThing()) {
                if (objMaterial.getName().equals(requiredMaterial) && remainingMaterial > 0) {
                    // objek Material digunakan oleh Equipment
                    ((Material) objMaterial).used(this);
                    remainingMaterial--;
                } else if (objMaterial.getName().equals(requiredMaterial) && remainingMaterial == 0) {
                    // objek Material dikembalikan ke userInventory
                    ((Item) objMaterial).moveTo(GameInfo.userInventory);
                }
            }
        }
    }

    public void returnMaterials() { // pindahkan material ke userInventory
        getArrThing().forEach(objMaterial -> ((Item) objMaterial).moveTo(GameInfo.userInventory));
    }

    public int countMaterials() {
        // note : isi arrThing dari objek turunan Equipment hanya objek Material
        // hitung jumlah objek Material yang tersedia dan diperlukan untuk levelUp
        HashMap<String, Long> materials =
                (HashMap<String, Long>) getArrThing().stream()
                        .collect(groupingBy(Thing::getName, counting()));

        int availableItem = 0;
        for (String requiredMaterial : requiredMaterials.keySet())
            for (String availableMaterial : materials.keySet())
                if (requiredMaterial.equals(availableMaterial)
                        && requiredMaterials.get(requiredMaterial)
                        <= materials.get(availableMaterial).intValue())
                    // total akhir harus == jumlah persyaratan Material
                    availableItem++;

        return availableItem;
    }

    // Getter
    public boolean isEquip() { return isEquip; }

    public int getLevel() { return level; }

    public int getUpgradeCost() { return upgradeCost; }

    public ArrayList<Multiplier> getMultipliers() { return multipliers; }
}
